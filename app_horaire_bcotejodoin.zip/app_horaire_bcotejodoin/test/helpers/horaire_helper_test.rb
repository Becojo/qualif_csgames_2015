require 'test_helper'

class HoraireHelperTest < ActionView::TestCase
end
