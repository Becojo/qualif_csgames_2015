require 'test_helper'

class ParticipantsHelperTest < ActionView::TestCase
end
