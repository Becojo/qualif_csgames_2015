require 'test_helper'

class CompetitionsHelperTest < ActionView::TestCase
end
