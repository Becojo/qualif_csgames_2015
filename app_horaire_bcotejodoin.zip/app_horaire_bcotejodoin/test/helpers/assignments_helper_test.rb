require 'test_helper'

class AssignmentsHelperTest < ActionView::TestCase
end
