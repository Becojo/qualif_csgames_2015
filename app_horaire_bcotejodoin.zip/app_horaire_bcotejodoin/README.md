# Horaire

## Dépendances

- Ruby
- Sqlite

Pour les gems, `bundle` 

## Exécution

`rails s`


